import { useEffect } from "react";

export function Toaster() {
  useEffect(() => {
    console.log("Toaster placeholder mounted.");
  }, []);

  return null;
}
